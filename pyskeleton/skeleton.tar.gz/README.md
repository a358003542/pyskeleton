# pyskeleton


## description:
a small tool make you creat new python project quickly.

## install
```
python3 setup.py install
```
or
```
pip3 install pyskeleton
```

## usage
```
pyskeleton newprojectname
```


## test
use pytest do the test thing.
```
python3 setup.py test
```
