##skeleton命令行工具
========

a python project skeleton。

本项目将实现一个小脚本功能，就是

    skeleton  yourprojectname
    
这时项目里面所有的skeleton名字都将替换成为yourprojectname，这样将会少点编辑量了。
