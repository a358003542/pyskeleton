skeleton
====
description:
a small tool make you creat new python project quickly.

usage:
    skeleton newprojectname



## test
use pytest do the test thing.
    python3 setup.py test
