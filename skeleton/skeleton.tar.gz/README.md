skeleton
====
description:
a small tool make you creat new python project quickly.

usage:
    skeleton newprojectname


