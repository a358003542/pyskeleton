#!/usr/bin/env python3
#-*-coding:utf-8-*-


"""skeleton模块make you start a new python project easier"""



__softname__ = 'skeleton'
__version__ = '0.1'




#if __name__ == '__main__':

