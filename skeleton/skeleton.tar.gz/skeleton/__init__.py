#!/usr/bin/env python3
#-*-coding:utf-8-*-


"""skeleton module make you start a new python project easier and quickly."""



__softname__ = 'skeleton'
__version__ = '0.2.1'




#if __name__ == '__main__':

