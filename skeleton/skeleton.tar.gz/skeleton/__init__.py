#!/usr/bin/env python3

"""skeleton模块make you start a new python project easier"""


#__all__ = ['anothermod']

__softname__ = 'skeleton'
__version__ = '0.1'




#if __name__ == '__main__':

