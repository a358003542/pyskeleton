#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import unicode_literals




def test_hello():
    print('test ready')














#if __name__ == '__main__':
